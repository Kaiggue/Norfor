<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                   ATTENTION!
 * If you see this message in your browser (Internet Explorer, Mozilla Firefox, Google Chrome, etc.)
 * this means that PHP is not properly installed on your web server. Please refer to the PHP manual
 * for more details: http://php.net/manual/install.php 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */

    include_once dirname(__FILE__) . '/components/startup.php';
    include_once dirname(__FILE__) . '/components/application.php';
    include_once dirname(__FILE__) . '/' . 'authorization.php';


    include_once dirname(__FILE__) . '/' . 'database_engine/mysql_engine.php';
    include_once dirname(__FILE__) . '/' . 'components/page/page_includes.php';

    function GetConnectionOptions()
    {
        $result = GetGlobalConnectionOptions();
        $result['client_encoding'] = 'utf8';
        GetApplication()->GetUserAuthentication()->applyIdentityToConnectionOptions($result);
        return $result;
    }

    
    
    
    
    // OnBeforePageExecute event handler
    
    
    
    class estibas_ingresosPage extends DetailPage
    {
        protected function DoBeforeCreate()
        {
            $this->SetTitle('Ingresos');
            $this->SetMenuLabel('Ingresos');
    
            $this->dataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`ingresos`');
            $this->dataset->addFields(
                array(
                    new IntegerField('pkIngreso', true, true, true),
                    new DateField('Fecha_ing'),
                    new IntegerField('CantRollos_ing'),
                    new IntegerField('RollosConsum_ing'),
                    new IntegerField('FSC_ing'),
                    new IntegerField('fkClase'),
                    new IntegerField('fkEstiba'),
                    new IntegerField('fkProveedor'),
                    new IntegerField('fkUsuario_alta')
                )
            );
            $this->dataset->AddLookupField('fkClase', 'clases', new IntegerField('pkClase'), new StringField('Nom_Clase', false, false, false, false, 'fkClase_Nom_Clase', 'fkClase_Nom_Clase_clases'), 'fkClase_Nom_Clase_clases');
            $this->dataset->AddLookupField('fkProveedor', 'proveedores', new IntegerField('pkProveedores'), new StringField('nombre_prove', false, false, false, false, 'fkProveedor_nombre_prove', 'fkProveedor_nombre_prove_proveedores'), 'fkProveedor_nombre_prove_proveedores');
            $this->dataset->AddLookupField('fkUsuario_alta', 'usuarios', new IntegerField('pkUsuario'), new StringField('usuario', false, false, false, false, 'fkUsuario_alta_usuario', 'fkUsuario_alta_usuario_usuarios'), 'fkUsuario_alta_usuario_usuarios');
        }
    
        protected function DoPrepare() {
    
        }
    
        protected function CreatePageNavigator()
        {
            $result = new CompositePageNavigator($this);
            
            $partitionNavigator = new PageNavigator('pnav', $this, $this->dataset);
            $partitionNavigator->SetRowsPerPage(20);
            $result->AddPageNavigator($partitionNavigator);
            
            return $result;
        }
    
        protected function CreateRssGenerator()
        {
            return null;
        }
    
        protected function setupCharts()
        {
    
        }
    
        protected function getFiltersColumns()
        {
            return array(
                new FilterColumn($this->dataset, 'pkIngreso', 'pkIngreso', 'Pk Ingreso'),
                new FilterColumn($this->dataset, 'Fecha_ing', 'Fecha_ing', 'Fecha Ing'),
                new FilterColumn($this->dataset, 'CantRollos_ing', 'CantRollos_ing', 'Cant Rollos Ing'),
                new FilterColumn($this->dataset, 'RollosConsum_ing', 'RollosConsum_ing', 'Rollos Consum Ing'),
                new FilterColumn($this->dataset, 'FSC_ing', 'FSC_ing', 'FSC Ing'),
                new FilterColumn($this->dataset, 'fkClase', 'fkClase_Nom_Clase', 'Fk Clase'),
                new FilterColumn($this->dataset, 'fkEstiba', 'fkEstiba', 'Fk Estiba'),
                new FilterColumn($this->dataset, 'fkProveedor', 'fkProveedor_nombre_prove', 'Fk Proveedor'),
                new FilterColumn($this->dataset, 'fkUsuario_alta', 'fkUsuario_alta_usuario', 'Fk Usuario Alta')
            );
        }
    
        protected function setupQuickFilter(QuickFilter $quickFilter, FixedKeysArray $columns)
        {
            $quickFilter
                ->addColumn($columns['pkIngreso'])
                ->addColumn($columns['Fecha_ing'])
                ->addColumn($columns['CantRollos_ing'])
                ->addColumn($columns['RollosConsum_ing'])
                ->addColumn($columns['FSC_ing'])
                ->addColumn($columns['fkClase'])
                ->addColumn($columns['fkEstiba'])
                ->addColumn($columns['fkProveedor'])
                ->addColumn($columns['fkUsuario_alta']);
        }
    
        protected function setupColumnFilter(ColumnFilter $columnFilter)
        {
            $columnFilter
                ->setOptionsFor('Fecha_ing')
                ->setOptionsFor('fkClase')
                ->setOptionsFor('fkEstiba')
                ->setOptionsFor('fkProveedor')
                ->setOptionsFor('fkUsuario_alta');
        }
    
        protected function setupFilterBuilder(FilterBuilder $filterBuilder, FixedKeysArray $columns)
        {
            $main_editor = new TextEdit('pkingreso_edit');
            
            $filterBuilder->addColumn(
                $columns['pkIngreso'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new DateTimeEdit('fecha_ing_edit', false, 'd-m-Y');
            
            $filterBuilder->addColumn(
                $columns['Fecha_ing'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::DATE_EQUALS => $main_editor,
                    FilterConditionOperator::DATE_DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::TODAY => null,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new TextEdit('cantrollos_ing_edit');
            
            $filterBuilder->addColumn(
                $columns['CantRollos_ing'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new TextEdit('rollosconsum_ing_edit');
            
            $filterBuilder->addColumn(
                $columns['RollosConsum_ing'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new TextEdit('fsc_ing_edit');
            
            $filterBuilder->addColumn(
                $columns['FSC_ing'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new DynamicCombobox('fkclase_edit', $this->CreateLinkBuilder());
            $main_editor->setAllowClear(true);
            $main_editor->setMinimumInputLength(0);
            $main_editor->SetAllowNullValue(false);
            $main_editor->SetHandlerName('filter_builder_estibas_ingresos_fkClase_search');
            
            $multi_value_select_editor = new RemoteMultiValueSelect('fkClase', $this->CreateLinkBuilder());
            $multi_value_select_editor->SetHandlerName('filter_builder_estibas_ingresos_fkClase_search');
            
            $text_editor = new TextEdit('fkClase');
            
            $filterBuilder->addColumn(
                $columns['fkClase'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::CONTAINS => $text_editor,
                    FilterConditionOperator::DOES_NOT_CONTAIN => $text_editor,
                    FilterConditionOperator::BEGINS_WITH => $text_editor,
                    FilterConditionOperator::ENDS_WITH => $text_editor,
                    FilterConditionOperator::IS_LIKE => $text_editor,
                    FilterConditionOperator::IS_NOT_LIKE => $text_editor,
                    FilterConditionOperator::IN => $multi_value_select_editor,
                    FilterConditionOperator::NOT_IN => $multi_value_select_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new TextEdit('fkestiba_edit');
            
            $filterBuilder->addColumn(
                $columns['fkEstiba'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::CONTAINS => $main_editor,
                    FilterConditionOperator::DOES_NOT_CONTAIN => $main_editor,
                    FilterConditionOperator::BEGINS_WITH => $main_editor,
                    FilterConditionOperator::ENDS_WITH => $main_editor,
                    FilterConditionOperator::IS_LIKE => $main_editor,
                    FilterConditionOperator::IS_NOT_LIKE => $main_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new DynamicCombobox('fkproveedor_edit', $this->CreateLinkBuilder());
            $main_editor->setAllowClear(true);
            $main_editor->setMinimumInputLength(0);
            $main_editor->SetAllowNullValue(false);
            $main_editor->SetHandlerName('filter_builder_estibas_ingresos_fkProveedor_search');
            
            $multi_value_select_editor = new RemoteMultiValueSelect('fkProveedor', $this->CreateLinkBuilder());
            $multi_value_select_editor->SetHandlerName('filter_builder_estibas_ingresos_fkProveedor_search');
            
            $text_editor = new TextEdit('fkProveedor');
            
            $filterBuilder->addColumn(
                $columns['fkProveedor'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::CONTAINS => $text_editor,
                    FilterConditionOperator::DOES_NOT_CONTAIN => $text_editor,
                    FilterConditionOperator::BEGINS_WITH => $text_editor,
                    FilterConditionOperator::ENDS_WITH => $text_editor,
                    FilterConditionOperator::IS_LIKE => $text_editor,
                    FilterConditionOperator::IS_NOT_LIKE => $text_editor,
                    FilterConditionOperator::IN => $multi_value_select_editor,
                    FilterConditionOperator::NOT_IN => $multi_value_select_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new DynamicCombobox('fkusuario_alta_edit', $this->CreateLinkBuilder());
            $main_editor->setAllowClear(true);
            $main_editor->setMinimumInputLength(0);
            $main_editor->SetAllowNullValue(false);
            $main_editor->SetHandlerName('filter_builder_estibas_ingresos_fkUsuario_alta_search');
            
            $multi_value_select_editor = new RemoteMultiValueSelect('fkUsuario_alta', $this->CreateLinkBuilder());
            $multi_value_select_editor->SetHandlerName('filter_builder_estibas_ingresos_fkUsuario_alta_search');
            
            $text_editor = new TextEdit('fkUsuario_alta');
            
            $filterBuilder->addColumn(
                $columns['fkUsuario_alta'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::CONTAINS => $text_editor,
                    FilterConditionOperator::DOES_NOT_CONTAIN => $text_editor,
                    FilterConditionOperator::BEGINS_WITH => $text_editor,
                    FilterConditionOperator::ENDS_WITH => $text_editor,
                    FilterConditionOperator::IS_LIKE => $text_editor,
                    FilterConditionOperator::IS_NOT_LIKE => $text_editor,
                    FilterConditionOperator::IN => $multi_value_select_editor,
                    FilterConditionOperator::NOT_IN => $multi_value_select_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
        }
    
        protected function AddOperationsColumns(Grid $grid)
        {
            $actions = $grid->getActions();
            $actions->setCaption($this->GetLocalizerCaptions()->GetMessageString('Actions'));
            $actions->setPosition(ActionList::POSITION_LEFT);
            
            if ($this->GetSecurityInfo()->HasViewGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('View'), OPERATION_VIEW, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
            }
            
            if ($this->GetSecurityInfo()->HasEditGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('Edit'), OPERATION_EDIT, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
                $operation->OnShow->AddListener('ShowEditButtonHandler', $this);
            }
            
            if ($this->GetSecurityInfo()->HasDeleteGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('Delete'), OPERATION_DELETE, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
                $operation->OnShow->AddListener('ShowDeleteButtonHandler', $this);
                $operation->SetAdditionalAttribute('data-modal-operation', 'delete');
                $operation->SetAdditionalAttribute('data-delete-handler-name', $this->GetModalGridDeleteHandler());
            }
            
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('Copy'), OPERATION_COPY, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
            }
        }
    
        protected function AddFieldColumns(Grid $grid, $withDetails = true)
        {
            //
            // View column for pkIngreso field
            //
            $column = new NumberViewColumn('pkIngreso', 'pkIngreso', 'Pk Ingreso', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for Fecha_ing field
            //
            $column = new DateTimeViewColumn('Fecha_ing', 'Fecha_ing', 'Fecha Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDateTimeFormat('Y-m-d');
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for CantRollos_ing field
            //
            $column = new NumberViewColumn('CantRollos_ing', 'CantRollos_ing', 'Cant Rollos Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for RollosConsum_ing field
            //
            $column = new NumberViewColumn('RollosConsum_ing', 'RollosConsum_ing', 'Rollos Consum Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for FSC_ing field
            //
            $column = new NumberViewColumn('FSC_ing', 'FSC_ing', 'FSC Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for Nom_Clase field
            //
            $column = new TextViewColumn('fkClase', 'fkClase_Nom_Clase', 'Fk Clase', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for fkEstiba field
            //
            $column = new TextViewColumn('fkEstiba', 'fkEstiba', 'Fk Estiba', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for nombre_prove field
            //
            $column = new TextViewColumn('fkProveedor', 'fkProveedor_nombre_prove', 'Fk Proveedor', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for usuario field
            //
            $column = new TextViewColumn('fkUsuario_alta', 'fkUsuario_alta_usuario', 'Fk Usuario Alta', $this->dataset);
            $column->SetOrderable(true);
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
        }
    
        protected function AddSingleRecordViewColumns(Grid $grid)
        {
            //
            // View column for pkIngreso field
            //
            $column = new NumberViewColumn('pkIngreso', 'pkIngreso', 'Pk Ingreso', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for Fecha_ing field
            //
            $column = new DateTimeViewColumn('Fecha_ing', 'Fecha_ing', 'Fecha Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDateTimeFormat('Y-m-d');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for CantRollos_ing field
            //
            $column = new NumberViewColumn('CantRollos_ing', 'CantRollos_ing', 'Cant Rollos Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for RollosConsum_ing field
            //
            $column = new NumberViewColumn('RollosConsum_ing', 'RollosConsum_ing', 'Rollos Consum Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for FSC_ing field
            //
            $column = new NumberViewColumn('FSC_ing', 'FSC_ing', 'FSC Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for Nom_Clase field
            //
            $column = new TextViewColumn('fkClase', 'fkClase_Nom_Clase', 'Fk Clase', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for fkEstiba field
            //
            $column = new TextViewColumn('fkEstiba', 'fkEstiba', 'Fk Estiba', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for nombre_prove field
            //
            $column = new TextViewColumn('fkProveedor', 'fkProveedor_nombre_prove', 'Fk Proveedor', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for usuario field
            //
            $column = new TextViewColumn('fkUsuario_alta', 'fkUsuario_alta_usuario', 'Fk Usuario Alta', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
        }
    
        protected function AddEditColumns(Grid $grid)
        {
            //
            // Edit column for Fecha_ing field
            //
            $editor = new DateTimeEdit('fecha_ing_edit', false, 'd-m-Y');
            $editColumn = new CustomEditColumn('Fecha Ing', 'Fecha_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for CantRollos_ing field
            //
            $editor = new TextEdit('cantrollos_ing_edit');
            $editColumn = new CustomEditColumn('Cant Rollos Ing', 'CantRollos_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for RollosConsum_ing field
            //
            $editor = new TextEdit('rollosconsum_ing_edit');
            $editColumn = new CustomEditColumn('Rollos Consum Ing', 'RollosConsum_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for FSC_ing field
            //
            $editor = new TextEdit('fsc_ing_edit');
            $editColumn = new CustomEditColumn('FSC Ing', 'FSC_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fkClase field
            //
            $editor = new DynamicCombobox('fkclase_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`clases`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkClase', true, true, true),
                    new StringField('Nom_Clase')
                )
            );
            $lookupDataset->setOrderByField('Nom_Clase', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Clase', 'fkClase', 'fkClase_Nom_Clase', 'edit_estibas_ingresos_fkClase_search', $editor, $this->dataset, $lookupDataset, 'pkClase', 'Nom_Clase', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fkEstiba field
            //
            $editor = new TextEdit('fkestiba_edit');
            $editColumn = new CustomEditColumn('Fk Estiba', 'fkEstiba', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fkProveedor field
            //
            $editor = new DynamicCombobox('fkproveedor_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`proveedores`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkProveedores', true, true, true),
                    new StringField('nombre_prove')
                )
            );
            $lookupDataset->setOrderByField('nombre_prove', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Proveedor', 'fkProveedor', 'fkProveedor_nombre_prove', 'edit_estibas_ingresos_fkProveedor_search', $editor, $this->dataset, $lookupDataset, 'pkProveedores', 'nombre_prove', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fkUsuario_alta field
            //
            $editor = new DynamicCombobox('fkusuario_alta_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`usuarios`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkUsuario', true, true, true),
                    new StringField('usuario'),
                    new StringField('password')
                )
            );
            $lookupDataset->setOrderByField('usuario', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Usuario Alta', 'fkUsuario_alta', 'fkUsuario_alta_usuario', 'edit_estibas_ingresos_fkUsuario_alta_search', $editor, $this->dataset, $lookupDataset, 'pkUsuario', 'usuario', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
        }
    
        protected function AddMultiEditColumns(Grid $grid)
        {
            //
            // Edit column for Fecha_ing field
            //
            $editor = new DateTimeEdit('fecha_ing_edit', false, 'd-m-Y');
            $editColumn = new CustomEditColumn('Fecha Ing', 'Fecha_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
            
            //
            // Edit column for CantRollos_ing field
            //
            $editor = new TextEdit('cantrollos_ing_edit');
            $editColumn = new CustomEditColumn('Cant Rollos Ing', 'CantRollos_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
            
            //
            // Edit column for RollosConsum_ing field
            //
            $editor = new TextEdit('rollosconsum_ing_edit');
            $editColumn = new CustomEditColumn('Rollos Consum Ing', 'RollosConsum_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
            
            //
            // Edit column for FSC_ing field
            //
            $editor = new TextEdit('fsc_ing_edit');
            $editColumn = new CustomEditColumn('FSC Ing', 'FSC_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
            
            //
            // Edit column for fkClase field
            //
            $editor = new DynamicCombobox('fkclase_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`clases`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkClase', true, true, true),
                    new StringField('Nom_Clase')
                )
            );
            $lookupDataset->setOrderByField('Nom_Clase', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Clase', 'fkClase', 'fkClase_Nom_Clase', 'multi_edit_estibas_ingresos_fkClase_search', $editor, $this->dataset, $lookupDataset, 'pkClase', 'Nom_Clase', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
            
            //
            // Edit column for fkEstiba field
            //
            $editor = new TextEdit('fkestiba_edit');
            $editColumn = new CustomEditColumn('Fk Estiba', 'fkEstiba', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
            
            //
            // Edit column for fkProveedor field
            //
            $editor = new DynamicCombobox('fkproveedor_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`proveedores`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkProveedores', true, true, true),
                    new StringField('nombre_prove')
                )
            );
            $lookupDataset->setOrderByField('nombre_prove', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Proveedor', 'fkProveedor', 'fkProveedor_nombre_prove', 'multi_edit_estibas_ingresos_fkProveedor_search', $editor, $this->dataset, $lookupDataset, 'pkProveedores', 'nombre_prove', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
            
            //
            // Edit column for fkUsuario_alta field
            //
            $editor = new DynamicCombobox('fkusuario_alta_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`usuarios`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkUsuario', true, true, true),
                    new StringField('usuario'),
                    new StringField('password')
                )
            );
            $lookupDataset->setOrderByField('usuario', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Usuario Alta', 'fkUsuario_alta', 'fkUsuario_alta_usuario', 'multi_edit_estibas_ingresos_fkUsuario_alta_search', $editor, $this->dataset, $lookupDataset, 'pkUsuario', 'usuario', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
        }
    
        protected function AddInsertColumns(Grid $grid)
        {
            //
            // Edit column for Fecha_ing field
            //
            $editor = new DateTimeEdit('fecha_ing_edit', false, 'd-m-Y');
            $editColumn = new CustomEditColumn('Fecha Ing', 'Fecha_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for CantRollos_ing field
            //
            $editor = new TextEdit('cantrollos_ing_edit');
            $editColumn = new CustomEditColumn('Cant Rollos Ing', 'CantRollos_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for RollosConsum_ing field
            //
            $editor = new TextEdit('rollosconsum_ing_edit');
            $editColumn = new CustomEditColumn('Rollos Consum Ing', 'RollosConsum_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for FSC_ing field
            //
            $editor = new TextEdit('fsc_ing_edit');
            $editColumn = new CustomEditColumn('FSC Ing', 'FSC_ing', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fkClase field
            //
            $editor = new DynamicCombobox('fkclase_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`clases`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkClase', true, true, true),
                    new StringField('Nom_Clase')
                )
            );
            $lookupDataset->setOrderByField('Nom_Clase', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Clase', 'fkClase', 'fkClase_Nom_Clase', 'insert_estibas_ingresos_fkClase_search', $editor, $this->dataset, $lookupDataset, 'pkClase', 'Nom_Clase', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fkEstiba field
            //
            $editor = new TextEdit('fkestiba_edit');
            $editColumn = new CustomEditColumn('Fk Estiba', 'fkEstiba', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fkProveedor field
            //
            $editor = new DynamicCombobox('fkproveedor_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`proveedores`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkProveedores', true, true, true),
                    new StringField('nombre_prove')
                )
            );
            $lookupDataset->setOrderByField('nombre_prove', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Proveedor', 'fkProveedor', 'fkProveedor_nombre_prove', 'insert_estibas_ingresos_fkProveedor_search', $editor, $this->dataset, $lookupDataset, 'pkProveedores', 'nombre_prove', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fkUsuario_alta field
            //
            $editor = new DynamicCombobox('fkusuario_alta_edit', $this->CreateLinkBuilder());
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`usuarios`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkUsuario', true, true, true),
                    new StringField('usuario'),
                    new StringField('password')
                )
            );
            $lookupDataset->setOrderByField('usuario', 'ASC');
            $editColumn = new DynamicLookupEditColumn('Fk Usuario Alta', 'fkUsuario_alta', 'fkUsuario_alta_usuario', 'insert_estibas_ingresos_fkUsuario_alta_search', $editor, $this->dataset, $lookupDataset, 'pkUsuario', 'usuario', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            $grid->SetShowAddButton(true && $this->GetSecurityInfo()->HasAddGrant());
        }
    
        private function AddMultiUploadColumn(Grid $grid)
        {
    
        }
    
        protected function AddPrintColumns(Grid $grid)
        {
            //
            // View column for pkIngreso field
            //
            $column = new NumberViewColumn('pkIngreso', 'pkIngreso', 'Pk Ingreso', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddPrintColumn($column);
            
            //
            // View column for Fecha_ing field
            //
            $column = new DateTimeViewColumn('Fecha_ing', 'Fecha_ing', 'Fecha Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDateTimeFormat('Y-m-d');
            $grid->AddPrintColumn($column);
            
            //
            // View column for CantRollos_ing field
            //
            $column = new NumberViewColumn('CantRollos_ing', 'CantRollos_ing', 'Cant Rollos Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddPrintColumn($column);
            
            //
            // View column for RollosConsum_ing field
            //
            $column = new NumberViewColumn('RollosConsum_ing', 'RollosConsum_ing', 'Rollos Consum Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddPrintColumn($column);
            
            //
            // View column for FSC_ing field
            //
            $column = new NumberViewColumn('FSC_ing', 'FSC_ing', 'FSC Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddPrintColumn($column);
            
            //
            // View column for Nom_Clase field
            //
            $column = new TextViewColumn('fkClase', 'fkClase_Nom_Clase', 'Fk Clase', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddPrintColumn($column);
            
            //
            // View column for fkEstiba field
            //
            $column = new TextViewColumn('fkEstiba', 'fkEstiba', 'Fk Estiba', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddPrintColumn($column);
            
            //
            // View column for nombre_prove field
            //
            $column = new TextViewColumn('fkProveedor', 'fkProveedor_nombre_prove', 'Fk Proveedor', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddPrintColumn($column);
            
            //
            // View column for usuario field
            //
            $column = new TextViewColumn('fkUsuario_alta', 'fkUsuario_alta_usuario', 'Fk Usuario Alta', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
        }
    
        protected function AddExportColumns(Grid $grid)
        {
            //
            // View column for pkIngreso field
            //
            $column = new NumberViewColumn('pkIngreso', 'pkIngreso', 'Pk Ingreso', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddExportColumn($column);
            
            //
            // View column for Fecha_ing field
            //
            $column = new DateTimeViewColumn('Fecha_ing', 'Fecha_ing', 'Fecha Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDateTimeFormat('Y-m-d');
            $grid->AddExportColumn($column);
            
            //
            // View column for CantRollos_ing field
            //
            $column = new NumberViewColumn('CantRollos_ing', 'CantRollos_ing', 'Cant Rollos Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddExportColumn($column);
            
            //
            // View column for RollosConsum_ing field
            //
            $column = new NumberViewColumn('RollosConsum_ing', 'RollosConsum_ing', 'Rollos Consum Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddExportColumn($column);
            
            //
            // View column for FSC_ing field
            //
            $column = new NumberViewColumn('FSC_ing', 'FSC_ing', 'FSC Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddExportColumn($column);
            
            //
            // View column for Nom_Clase field
            //
            $column = new TextViewColumn('fkClase', 'fkClase_Nom_Clase', 'Fk Clase', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddExportColumn($column);
            
            //
            // View column for fkEstiba field
            //
            $column = new TextViewColumn('fkEstiba', 'fkEstiba', 'Fk Estiba', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddExportColumn($column);
            
            //
            // View column for nombre_prove field
            //
            $column = new TextViewColumn('fkProveedor', 'fkProveedor_nombre_prove', 'Fk Proveedor', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddExportColumn($column);
            
            //
            // View column for usuario field
            //
            $column = new TextViewColumn('fkUsuario_alta', 'fkUsuario_alta_usuario', 'Fk Usuario Alta', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
        }
    
        private function AddCompareColumns(Grid $grid)
        {
            //
            // View column for Fecha_ing field
            //
            $column = new DateTimeViewColumn('Fecha_ing', 'Fecha_ing', 'Fecha Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDateTimeFormat('Y-m-d');
            $grid->AddCompareColumn($column);
            
            //
            // View column for CantRollos_ing field
            //
            $column = new NumberViewColumn('CantRollos_ing', 'CantRollos_ing', 'Cant Rollos Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddCompareColumn($column);
            
            //
            // View column for RollosConsum_ing field
            //
            $column = new NumberViewColumn('RollosConsum_ing', 'RollosConsum_ing', 'Rollos Consum Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddCompareColumn($column);
            
            //
            // View column for FSC_ing field
            //
            $column = new NumberViewColumn('FSC_ing', 'FSC_ing', 'FSC Ing', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddCompareColumn($column);
            
            //
            // View column for Nom_Clase field
            //
            $column = new TextViewColumn('fkClase', 'fkClase_Nom_Clase', 'Fk Clase', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddCompareColumn($column);
            
            //
            // View column for fkEstiba field
            //
            $column = new TextViewColumn('fkEstiba', 'fkEstiba', 'Fk Estiba', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddCompareColumn($column);
            
            //
            // View column for nombre_prove field
            //
            $column = new TextViewColumn('fkProveedor', 'fkProveedor_nombre_prove', 'Fk Proveedor', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $grid->AddCompareColumn($column);
            
            //
            // View column for usuario field
            //
            $column = new TextViewColumn('fkUsuario_alta', 'fkUsuario_alta_usuario', 'Fk Usuario Alta', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddCompareColumn($column);
        }
    
        private function AddCompareHeaderColumns(Grid $grid)
        {
    
        }
    
        public function GetPageDirection()
        {
            return null;
        }
    
        public function isFilterConditionRequired()
        {
            return false;
        }
    
        protected function ApplyCommonColumnEditProperties(CustomEditColumn $column)
        {
            $column->SetDisplaySetToNullCheckBox(false);
            $column->SetDisplaySetToDefaultCheckBox(false);
    		$column->SetVariableContainer($this->GetColumnVariableContainer());
        }
    
        function GetCustomClientScript()
        {
            return ;
        }
        
        function GetOnPageLoadedClientScript()
        {
            return ;
        }
        protected function GetEnableModalGridDelete() { return true; }
    
        protected function CreateGrid()
        {
            $result = new Grid($this, $this->dataset);
            if ($this->GetSecurityInfo()->HasDeleteGrant())
               $result->SetAllowDeleteSelected(true);
            else
               $result->SetAllowDeleteSelected(false);   
            
            ApplyCommonPageSettings($this, $result);
            
            $result->SetUseImagesForActions(true);
            $result->SetUseFixedHeader(false);
            $result->SetShowLineNumbers(true);
            $result->SetShowKeyColumnsImagesInHeader(false);
            $result->SetViewMode(ViewMode::TABLE);
            $result->setEnableRuntimeCustomization(true);
            $result->setAllowCompare(true);
            $this->AddCompareHeaderColumns($result);
            $this->AddCompareColumns($result);
            $result->setMultiEditAllowed($this->GetSecurityInfo()->HasEditGrant() && true);
            $result->setTableBordered(false);
            $result->setTableCondensed(true);
            
            $result->SetHighlightRowAtHover(true);
            $result->SetWidth('');
            $this->AddOperationsColumns($result);
            $this->AddFieldColumns($result);
            $this->AddSingleRecordViewColumns($result);
            $this->AddEditColumns($result);
            $this->AddMultiEditColumns($result);
            $this->AddInsertColumns($result);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
            $this->AddMultiUploadColumn($result);
    
    
            $this->SetShowPageList(true);
            $this->SetShowTopPageNavigator(true);
            $this->SetShowBottomPageNavigator(true);
            $this->setPrintListAvailable(true);
            $this->setPrintListRecordAvailable(false);
            $this->setPrintOneRecordAvailable(true);
            $this->setAllowPrintSelectedRecords(true);
            $this->setExportListAvailable(array('pdf', 'excel', 'word', 'xml', 'csv'));
            $this->setExportSelectedRecordsAvailable(array('pdf', 'excel', 'word', 'xml', 'csv'));
            $this->setExportListRecordAvailable(array());
            $this->setExportOneRecordAvailable(array('pdf', 'excel', 'word', 'xml', 'csv'));
    
            return $result;
        }
     
        protected function setClientSideEvents(Grid $grid) {
    
        }
    
        protected function doRegisterHandlers() {
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`clases`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkClase', true, true, true),
                    new StringField('Nom_Clase')
                )
            );
            $lookupDataset->setOrderByField('Nom_Clase', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'insert_estibas_ingresos_fkClase_search', 'pkClase', 'Nom_Clase', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`proveedores`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkProveedores', true, true, true),
                    new StringField('nombre_prove')
                )
            );
            $lookupDataset->setOrderByField('nombre_prove', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'insert_estibas_ingresos_fkProveedor_search', 'pkProveedores', 'nombre_prove', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`usuarios`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkUsuario', true, true, true),
                    new StringField('usuario'),
                    new StringField('password')
                )
            );
            $lookupDataset->setOrderByField('usuario', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'insert_estibas_ingresos_fkUsuario_alta_search', 'pkUsuario', 'usuario', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`clases`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkClase', true, true, true),
                    new StringField('Nom_Clase')
                )
            );
            $lookupDataset->setOrderByField('Nom_Clase', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'filter_builder_estibas_ingresos_fkClase_search', 'pkClase', 'Nom_Clase', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`proveedores`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkProveedores', true, true, true),
                    new StringField('nombre_prove')
                )
            );
            $lookupDataset->setOrderByField('nombre_prove', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'filter_builder_estibas_ingresos_fkProveedor_search', 'pkProveedores', 'nombre_prove', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`usuarios`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkUsuario', true, true, true),
                    new StringField('usuario'),
                    new StringField('password')
                )
            );
            $lookupDataset->setOrderByField('usuario', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'filter_builder_estibas_ingresos_fkUsuario_alta_search', 'pkUsuario', 'usuario', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`clases`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkClase', true, true, true),
                    new StringField('Nom_Clase')
                )
            );
            $lookupDataset->setOrderByField('Nom_Clase', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'edit_estibas_ingresos_fkClase_search', 'pkClase', 'Nom_Clase', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`proveedores`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkProveedores', true, true, true),
                    new StringField('nombre_prove')
                )
            );
            $lookupDataset->setOrderByField('nombre_prove', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'edit_estibas_ingresos_fkProveedor_search', 'pkProveedores', 'nombre_prove', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`usuarios`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkUsuario', true, true, true),
                    new StringField('usuario'),
                    new StringField('password')
                )
            );
            $lookupDataset->setOrderByField('usuario', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'edit_estibas_ingresos_fkUsuario_alta_search', 'pkUsuario', 'usuario', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`clases`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkClase', true, true, true),
                    new StringField('Nom_Clase')
                )
            );
            $lookupDataset->setOrderByField('Nom_Clase', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'multi_edit_estibas_ingresos_fkClase_search', 'pkClase', 'Nom_Clase', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`proveedores`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkProveedores', true, true, true),
                    new StringField('nombre_prove')
                )
            );
            $lookupDataset->setOrderByField('nombre_prove', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'multi_edit_estibas_ingresos_fkProveedor_search', 'pkProveedores', 'nombre_prove', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
            
            $lookupDataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`usuarios`');
            $lookupDataset->addFields(
                array(
                    new IntegerField('pkUsuario', true, true, true),
                    new StringField('usuario'),
                    new StringField('password')
                )
            );
            $lookupDataset->setOrderByField('usuario', 'ASC');
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'multi_edit_estibas_ingresos_fkUsuario_alta_search', 'pkUsuario', 'usuario', null, 20);
            GetApplication()->RegisterHTTPHandler($handler);
        }
       
        protected function doCustomRenderColumn($fieldName, $fieldData, $rowData, &$customText, &$handled)
        { 
    
        }
    
        protected function doCustomRenderPrintColumn($fieldName, $fieldData, $rowData, &$customText, &$handled)
        { 
    
        }
    
        protected function doCustomRenderExportColumn($exportType, $fieldName, $fieldData, $rowData, &$customText, &$handled)
        { 
    
        }
    
        protected function doCustomDrawRow($rowData, &$cellFontColor, &$cellFontSize, &$cellBgColor, &$cellItalicAttr, &$cellBoldAttr)
        {
    
        }
    
        protected function doExtendedCustomDrawRow($rowData, &$rowCellStyles, &$rowStyles, &$rowClasses, &$cellClasses)
        {
    
        }
    
        protected function doCustomRenderTotal($totalValue, $aggregate, $columnName, &$customText, &$handled)
        {
    
        }
    
        protected function doCustomDefaultValues(&$values, &$handled) 
        {
    
        }
    
        protected function doCustomCompareColumn($columnName, $valueA, $valueB, &$result)
        {
    
        }
    
        protected function doBeforeInsertRecord($page, &$rowData, $tableName, &$cancel, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doBeforeUpdateRecord($page, $oldRowData, &$rowData, $tableName, &$cancel, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doBeforeDeleteRecord($page, &$rowData, $tableName, &$cancel, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doAfterInsertRecord($page, $rowData, $tableName, &$success, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doAfterUpdateRecord($page, $oldRowData, $rowData, $tableName, &$success, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doAfterDeleteRecord($page, $rowData, $tableName, &$success, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doCustomHTMLHeader($page, &$customHtmlHeaderText)
        { 
    
        }
    
        protected function doGetCustomTemplate($type, $part, $mode, &$result, &$params)
        {
    
        }
    
        protected function doGetCustomExportOptions(Page $page, $exportType, $rowData, &$options)
        {
    
        }
    
        protected function doFileUpload($fieldName, $rowData, &$result, &$accept, $originalFileName, $originalFileExtension, $fileSize, $tempFileName)
        {
    
        }
    
        protected function doPrepareChart(Chart $chart)
        {
    
        }
    
        protected function doPrepareColumnFilter(ColumnFilter $columnFilter)
        {
    
        }
    
        protected function doPrepareFilterBuilder(FilterBuilder $filterBuilder, FixedKeysArray $columns)
        {
    
        }
    
        protected function doGetSelectionFilters(FixedKeysArray $columns, &$result)
        {
    
        }
    
        protected function doGetCustomFormLayout($mode, FixedKeysArray $columns, FormLayout $layout)
        {
    
        }
    
        protected function doGetCustomColumnGroup(FixedKeysArray $columns, ViewColumnGroup $columnGroup)
        {
    
        }
    
        protected function doPageLoaded()
        {
    
        }
    
        protected function doCalculateFields($rowData, $fieldName, &$value)
        {
    
        }
    
        protected function doGetCustomRecordPermissions(Page $page, &$usingCondition, $rowData, &$allowEdit, &$allowDelete, &$mergeWithDefault, &$handled)
        {
    
        }
    
        protected function doAddEnvironmentVariables(Page $page, &$variables)
        {
    
        }
    
    }
    
    // OnBeforePageExecute event handler
    
    
    
    class estibasPage extends Page
    {
        protected function DoBeforeCreate()
        {
            $this->SetTitle('Estibas');
            $this->SetMenuLabel('Estibas');
    
            $this->dataset = new TableDataset(
                MySqlIConnectionFactory::getInstance(),
                GetConnectionOptions(),
                '`estibas`');
            $this->dataset->addFields(
                array(
                    new IntegerField('pkEstiba', true, true, true),
                    new StringField('fkesti'),
                    new IntegerField('FSC_est')
                )
            );
        }
    
        protected function DoPrepare() {
    
        }
    
        protected function CreatePageNavigator()
        {
            $result = new CompositePageNavigator($this);
            
            $partitionNavigator = new PageNavigator('pnav', $this, $this->dataset);
            $partitionNavigator->SetRowsPerPage(20);
            $result->AddPageNavigator($partitionNavigator);
            
            return $result;
        }
    
        protected function CreateRssGenerator()
        {
            return null;
        }
    
        protected function setupCharts()
        {
    
        }
    
        protected function getFiltersColumns()
        {
            return array(
                new FilterColumn($this->dataset, 'pkEstiba', 'pkEstiba', 'Pk Estiba'),
                new FilterColumn($this->dataset, 'FSC_est', 'FSC_est', 'FSC Estibas'),
                new FilterColumn($this->dataset, 'fkesti', 'fkesti', 'Fkesti')
            );
        }
    
        protected function setupQuickFilter(QuickFilter $quickFilter, FixedKeysArray $columns)
        {
            $quickFilter
                ->addColumn($columns['pkEstiba'])
                ->addColumn($columns['FSC_est']);
        }
    
        protected function setupColumnFilter(ColumnFilter $columnFilter)
        {
    
        }
    
        protected function setupFilterBuilder(FilterBuilder $filterBuilder, FixedKeysArray $columns)
        {
            $main_editor = new TextEdit('pkestiba_edit');
            
            $filterBuilder->addColumn(
                $columns['pkEstiba'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
            
            $main_editor = new TextEdit('fsc_est_edit');
            
            $filterBuilder->addColumn(
                $columns['FSC_est'],
                array(
                    FilterConditionOperator::EQUALS => $main_editor,
                    FilterConditionOperator::DOES_NOT_EQUAL => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN => $main_editor,
                    FilterConditionOperator::IS_GREATER_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN => $main_editor,
                    FilterConditionOperator::IS_LESS_THAN_OR_EQUAL_TO => $main_editor,
                    FilterConditionOperator::IS_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_NOT_BETWEEN => $main_editor,
                    FilterConditionOperator::IS_BLANK => null,
                    FilterConditionOperator::IS_NOT_BLANK => null
                )
            );
        }
    
        protected function AddOperationsColumns(Grid $grid)
        {
            $actions = $grid->getActions();
            $actions->setCaption($this->GetLocalizerCaptions()->GetMessageString('Actions'));
            $actions->setPosition(ActionList::POSITION_LEFT);
            
            if ($this->GetSecurityInfo()->HasViewGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('View'), OPERATION_VIEW, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
            }
            
            if ($this->GetSecurityInfo()->HasEditGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('Edit'), OPERATION_EDIT, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
                $operation->OnShow->AddListener('ShowEditButtonHandler', $this);
            }
            
            if ($this->GetSecurityInfo()->HasDeleteGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('Delete'), OPERATION_DELETE, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
                $operation->OnShow->AddListener('ShowDeleteButtonHandler', $this);
                $operation->SetAdditionalAttribute('data-modal-operation', 'delete');
                $operation->SetAdditionalAttribute('data-delete-handler-name', $this->GetModalGridDeleteHandler());
            }
            
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $operation = new LinkOperation($this->GetLocalizerCaptions()->GetMessageString('Copy'), OPERATION_COPY, $this->dataset, $grid);
                $operation->setUseImage(true);
                $actions->addOperation($operation);
            }
        }
    
        protected function AddFieldColumns(Grid $grid, $withDetails = true)
        {
            if (GetCurrentUserPermissionsForPage('estibas.ingresos')->HasViewGrant() && $withDetails)
            {
            //
            // View column for estibas_ingresos detail
            //
            $column = new DetailColumn(array('pkEstiba'), 'estibas.ingresos', 'estibas_ingresos_handler', $this->dataset, 'Ingresos');
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $grid->AddViewColumn($column);
            }
            
            //
            // View column for FSC_est field
            //
            $column = new NumberViewColumn('FSC_est', 'FSC_est', 'FSC Estibas', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $column->setMinimalVisibility(ColumnVisibility::PHONE);
            $column->SetDescription('');
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
        }
    
        protected function AddSingleRecordViewColumns(Grid $grid)
        {
            //
            // View column for FSC_est field
            //
            $column = new NumberViewColumn('FSC_est', 'FSC_est', 'FSC Estibas', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddSingleRecordViewColumn($column);
        }
    
        protected function AddEditColumns(Grid $grid)
        {
            //
            // Edit column for FSC_est field
            //
            $editor = new TextEdit('fsc_est_edit');
            $editColumn = new CustomEditColumn('FSC Estibas', 'FSC_est', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
        }
    
        protected function AddMultiEditColumns(Grid $grid)
        {
            //
            // Edit column for FSC_est field
            //
            $editor = new TextEdit('fsc_est_edit');
            $editColumn = new CustomEditColumn('FSC Estibas', 'FSC_est', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddMultiEditColumn($editColumn);
        }
    
        protected function AddInsertColumns(Grid $grid)
        {
            //
            // Edit column for FSC_est field
            //
            $editor = new TextEdit('fsc_est_edit');
            $editColumn = new CustomEditColumn('FSC Estibas', 'FSC_est', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            $grid->SetShowAddButton(true && $this->GetSecurityInfo()->HasAddGrant());
        }
    
        private function AddMultiUploadColumn(Grid $grid)
        {
    
        }
    
        protected function AddPrintColumns(Grid $grid)
        {
            //
            // View column for pkEstiba field
            //
            $column = new NumberViewColumn('pkEstiba', 'pkEstiba', 'Pk Estiba', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddPrintColumn($column);
            
            //
            // View column for FSC_est field
            //
            $column = new NumberViewColumn('FSC_est', 'FSC_est', 'FSC Estibas', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddPrintColumn($column);
        }
    
        protected function AddExportColumns(Grid $grid)
        {
            //
            // View column for pkEstiba field
            //
            $column = new NumberViewColumn('pkEstiba', 'pkEstiba', 'Pk Estiba', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddExportColumn($column);
            
            //
            // View column for FSC_est field
            //
            $column = new NumberViewColumn('FSC_est', 'FSC_est', 'FSC Estibas', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddExportColumn($column);
        }
    
        private function AddCompareColumns(Grid $grid)
        {
            //
            // View column for FSC_est field
            //
            $column = new NumberViewColumn('FSC_est', 'FSC_est', 'FSC Estibas', $this->dataset);
            $column->SetOrderable(true);
            $column->setNumberAfterDecimal(0);
            $column->setThousandsSeparator(',');
            $column->setDecimalSeparator('');
            $grid->AddCompareColumn($column);
        }
    
        private function AddCompareHeaderColumns(Grid $grid)
        {
    
        }
    
        public function GetPageDirection()
        {
            return null;
        }
    
        public function isFilterConditionRequired()
        {
            return false;
        }
    
        protected function ApplyCommonColumnEditProperties(CustomEditColumn $column)
        {
            $column->SetDisplaySetToNullCheckBox(false);
            $column->SetDisplaySetToDefaultCheckBox(false);
    		$column->SetVariableContainer($this->GetColumnVariableContainer());
        }
    
        function CreateMasterDetailRecordGrid()
        {
            $result = new Grid($this, $this->dataset);
            
            $this->AddFieldColumns($result, false);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
            
            $result->SetAllowDeleteSelected(false);
            $result->SetShowUpdateLink(false);
            $result->SetShowKeyColumnsImagesInHeader(false);
            $result->SetViewMode(ViewMode::TABLE);
            $result->setEnableRuntimeCustomization(false);
            $result->setTableBordered(false);
            $result->setTableCondensed(true);
            
            $this->setupGridColumnGroup($result);
            $this->attachGridEventHandlers($result);
            
            return $result;
        }
        
        function GetCustomClientScript()
        {
            return ;
        }
        
        function GetOnPageLoadedClientScript()
        {
            return ;
        }
        protected function GetEnableModalGridDelete() { return true; }
    
        protected function CreateGrid()
        {
            $result = new Grid($this, $this->dataset);
            if ($this->GetSecurityInfo()->HasDeleteGrant())
               $result->SetAllowDeleteSelected(true);
            else
               $result->SetAllowDeleteSelected(false);   
            
            ApplyCommonPageSettings($this, $result);
            
            $result->SetUseImagesForActions(true);
            $result->SetUseFixedHeader(false);
            $result->SetShowLineNumbers(true);
            $result->SetShowKeyColumnsImagesInHeader(false);
            $result->SetViewMode(ViewMode::TABLE);
            $result->setEnableRuntimeCustomization(true);
            $result->setAllowCompare(true);
            $this->AddCompareHeaderColumns($result);
            $this->AddCompareColumns($result);
            $result->setMultiEditAllowed($this->GetSecurityInfo()->HasEditGrant() && true);
            $result->setTableBordered(false);
            $result->setTableCondensed(true);
            
            $result->SetHighlightRowAtHover(true);
            $result->SetWidth('');
            $this->AddOperationsColumns($result);
            $this->AddFieldColumns($result);
            $this->AddSingleRecordViewColumns($result);
            $this->AddEditColumns($result);
            $this->AddMultiEditColumns($result);
            $this->AddInsertColumns($result);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
            $this->AddMultiUploadColumn($result);
    
    
            $this->SetShowPageList(true);
            $this->SetShowTopPageNavigator(true);
            $this->SetShowBottomPageNavigator(true);
            $this->setPrintListAvailable(true);
            $this->setPrintListRecordAvailable(false);
            $this->setPrintOneRecordAvailable(true);
            $this->setAllowPrintSelectedRecords(true);
            $this->setExportListAvailable(array('pdf', 'excel', 'word', 'xml', 'csv'));
            $this->setExportSelectedRecordsAvailable(array('pdf', 'excel', 'word', 'xml', 'csv'));
            $this->setExportListRecordAvailable(array());
            $this->setExportOneRecordAvailable(array('pdf', 'excel', 'word', 'xml', 'csv'));
    
            return $result;
        }
     
        protected function setClientSideEvents(Grid $grid) {
    
        }
    
        protected function doRegisterHandlers() {
            $detailPage = new estibas_ingresosPage('estibas_ingresos', $this, array('fkEstiba'), array('pkEstiba'), $this->GetForeignKeyFields(), $this->CreateMasterDetailRecordGrid(), $this->dataset, GetCurrentUserPermissionsForPage('estibas.ingresos'), 'UTF-8');
            $detailPage->SetRecordPermission(GetCurrentUserRecordPermissionsForDataSource('estibas.ingresos'));
            $detailPage->SetHttpHandlerName('estibas_ingresos_handler');
            $handler = new PageHTTPHandler('estibas_ingresos_handler', $detailPage);
            GetApplication()->RegisterHTTPHandler($handler);
            
        }
       
        protected function doCustomRenderColumn($fieldName, $fieldData, $rowData, &$customText, &$handled)
        { 
    
        }
    
        protected function doCustomRenderPrintColumn($fieldName, $fieldData, $rowData, &$customText, &$handled)
        { 
    
        }
    
        protected function doCustomRenderExportColumn($exportType, $fieldName, $fieldData, $rowData, &$customText, &$handled)
        { 
    
        }
    
        protected function doCustomDrawRow($rowData, &$cellFontColor, &$cellFontSize, &$cellBgColor, &$cellItalicAttr, &$cellBoldAttr)
        {
    
        }
    
        protected function doExtendedCustomDrawRow($rowData, &$rowCellStyles, &$rowStyles, &$rowClasses, &$cellClasses)
        {
    
        }
    
        protected function doCustomRenderTotal($totalValue, $aggregate, $columnName, &$customText, &$handled)
        {
    
        }
    
        protected function doCustomDefaultValues(&$values, &$handled) 
        {
    
        }
    
        protected function doCustomCompareColumn($columnName, $valueA, $valueB, &$result)
        {
    
        }
    
        protected function doBeforeInsertRecord($page, &$rowData, $tableName, &$cancel, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doBeforeUpdateRecord($page, $oldRowData, &$rowData, $tableName, &$cancel, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doBeforeDeleteRecord($page, &$rowData, $tableName, &$cancel, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doAfterInsertRecord($page, $rowData, $tableName, &$success, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doAfterUpdateRecord($page, $oldRowData, $rowData, $tableName, &$success, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doAfterDeleteRecord($page, $rowData, $tableName, &$success, &$message, &$messageDisplayTime)
        {
    
        }
    
        protected function doCustomHTMLHeader($page, &$customHtmlHeaderText)
        { 
    
        }
    
        protected function doGetCustomTemplate($type, $part, $mode, &$result, &$params)
        {
    
        }
    
        protected function doGetCustomExportOptions(Page $page, $exportType, $rowData, &$options)
        {
    
        }
    
        protected function doFileUpload($fieldName, $rowData, &$result, &$accept, $originalFileName, $originalFileExtension, $fileSize, $tempFileName)
        {
    
        }
    
        protected function doPrepareChart(Chart $chart)
        {
    
        }
    
        protected function doPrepareColumnFilter(ColumnFilter $columnFilter)
        {
    
        }
    
        protected function doPrepareFilterBuilder(FilterBuilder $filterBuilder, FixedKeysArray $columns)
        {
    
        }
    
        protected function doGetSelectionFilters(FixedKeysArray $columns, &$result)
        {
    
        }
    
        protected function doGetCustomFormLayout($mode, FixedKeysArray $columns, FormLayout $layout)
        {
    
        }
    
        protected function doGetCustomColumnGroup(FixedKeysArray $columns, ViewColumnGroup $columnGroup)
        {
    
        }
    
        protected function doPageLoaded()
        {
    
        }
    
        protected function doCalculateFields($rowData, $fieldName, &$value)
        {
    
        }
    
        protected function doGetCustomRecordPermissions(Page $page, &$usingCondition, $rowData, &$allowEdit, &$allowDelete, &$mergeWithDefault, &$handled)
        {
    
        }
    
        protected function doAddEnvironmentVariables(Page $page, &$variables)
        {
    
        }
    
    }

    SetUpUserAuthorization();

    try
    {
        $Page = new estibasPage("estibas", "estibas.php", GetCurrentUserPermissionsForPage("estibas"), 'UTF-8');
        $Page->SetRecordPermission(GetCurrentUserRecordPermissionsForDataSource("estibas"));
        GetApplication()->SetMainPage($Page);
        GetApplication()->Run();
    }
    catch(Exception $e)
    {
        ShowErrorPage($e);
    }
	
